import React from "react";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
//import '.../complement/teste/App.css';
//import InputLabel from "@material-ui/core/InputLabel";
// core components
import GridItem from "components/Grid/GridItem.js";
import GridContainer from "components/Grid/GridContainer.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import Button from "components/CustomButtons/Button.js";
import Table from "components/Table/Table.js";

import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";


const styles = {
  cardCategoryWhite: {
    color: "rgba(255,255,255,.62)",
    margin: "0",
    fontSize: "14px",
    marginTop: "0",
    marginBottom: "0"
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  }  
};

const useStyles = makeStyles(styles);

//const [isModalVisible, setIsModalVisible] = useState(false)

export default function UserProfile() {
  const classes = useStyles();
  return (
    <div>
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardHeader color="primary">
              <h4 className={classes.cardTitleWhite}>PERFIL DO USUÁRIO</h4>
              
            </CardHeader>
            <CardBody>
              <GridContainer>
                <GridItem xs={12} sm={12} md={3}>
                  <CustomInput
                    labelText="CPF"
                    id="cpf"
                    formControlProps={{
                      fullWidth: true
                    }}
                    inputProps={{
                      disabled: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={5}>
                  <CustomInput
                    labelText="NAME"
                    id="username"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={6}>
                  <CustomInput
                    labelText="EMAIL"
                    id="email-address"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
              
                <GridItem xs={12} sm={12} md={3}>
                  <CustomInput
                    labelText="TELEFONE"
                    id="telefone"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
              </GridContainer>
              <GridContainer>
                <GridItem xs={12} sm={12} md={5}>
                  <CustomInput
                    labelText="RUA"
                    id="street"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="CIDADE"
                    id="city"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="ESTADO"
                    id="states"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="BAIRRO"
                    id="district"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={1}>
                  <CustomInput
                    labelText="NÚMERO"
                    id="number"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={4}>
                  <CustomInput
                    labelText="COMPLEMENTO"
                    id="complement"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={2}>
                  <CustomInput
                    labelText="Postal Code"
                    id="postal-code"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
                <GridItem xs={12} sm={12} md={3}>
                  <CustomInput
                    labelText="DATA DE CIAÇÃO DA CONTA"
                    id="date-create-account"
                    formControlProps={{
                      fullWidth: true
                    }}
                  />
                </GridItem>
              </GridContainer>
              <GridContainer>
                
              </GridContainer>
              
            </CardBody>
            <CardFooter>
              <Button color="primary">SALVAR EDIÇÃO</Button>
            </CardFooter>
          </Card>
        </GridItem>
        
        <GridItem xs={12} sm={12} md={12}>
        <Card plain>
          <CardHeader plain color="primary">
            <h4 className={classes.cardTitleWhite}> TABELA DE PAGAMENTOS </h4>
            
          </CardHeader>
          <CardBody>
            <Table
              tableHeaderColor="white"
              tableHead={["ID", "NOME", "VALOR", "DATA DO PEDIDO", "STATUS", "FORMA DE PAGAMENTO", "PARCELAS"]}
              tableData={[
                ["1", "Marcos", "$36.789", "20/03/2021", "EM ANDAMENTO", "CARTÃO DE CREDITO", "1X"],
                ["2", "Andre", "$32.000", "20/03/2021"],
                ["3", "Dyone"]
              ]}
            />
          </CardBody>
        </Card>
        </GridItem>
        <GridItem xs={12} sm={12} md={12}>
        <Card plain color="white">
          <CardHeader plain color="primary">
            <h4 className={classes.cardTitleWhite}>
              TABELA DE LAUDOS
            </h4>
            
          </CardHeader>
          <CardBody>
            <Table
              tableHeaderColor="primary"
              tableHead={["LAUDOS", "ANEXADO", "ARQUIVO"]}
              tableData={[
                ["1", "22/03/2021", "PDF"],
                ["2", "21/03/2021", "PDF"],
                ["3", "20/03/2021", 'PDF']
              ]}
            />
          </CardBody>
          <CardFooter>
            
            <Button 
            color="primary" 
            onClick="Button()" 
            ><input type="file" 
            />
            </Button>

              
          </CardFooter>
        </Card>
        </GridItem>
      </GridContainer>
    </div>
  );
}